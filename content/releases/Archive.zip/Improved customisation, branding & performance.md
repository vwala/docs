---
title: "Improved customisation, branding & performance"
meta_title: "2017-08-30"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

We've just released a new version of [vwa.la.](http://vwa.la) This week we focused on various product improvements fixes: Changes include:

*   Emails sent to your referrers are now branded. They'll use your store name and will be branded with your theme.
*   You can now disable the in-store widget for mobile only devices. This is useful when you'd like to display the widget on desktop devices, but not on tablets, phones etc.�
*   We've optimised our stats engine. It's now much more efficient which means we can comfortable handle large transaction volumes.�
*   We've improve the referrer dashboard experience. It's now simpler to understand and shows all of their key information at first glance.
*   We've added an order conversion rate stat to your dashboard.�
*   We've spent some extra time giving our docs some love. We'll be making more improvements in this area over the next week or so.�
*   Various improvements to our payment system.�
*   We've improved the user on boarding tour experience.