---
title: "Single use discount codes, PayPal and order handling improvements"
meta_title: "2018-01-25"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

In this release we've focused on improving some of our core features.

**What's new?**

*   Merchant's can now opt for all of their referrer codes to be limited to a single use per customer (my account > store settings > business rules)
*   We've increased our PayPal payment time out window from 1 day to 15 days
*   Improved our support of partially fulfilled orders�
*   Made it clear that all billing plan prices are in USD
*   Fixed an issue with Mobile Safari 10.x not displaying correctly

Thanks all for your feedback :)