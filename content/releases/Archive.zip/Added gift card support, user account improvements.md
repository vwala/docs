---
title: "Added gift card support, user account improvements"
meta_title: "2017-09-16"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

We're excited to announce that we have released a new version of [vwa.la](http://vwa.la) with gift card support! This means you can now pay your referrer's their commission with a Shopify gift card. You can read more about this feature [here](https://intercom.help/vwala/merchant-help/paying-commission).

We've also made some improvements to our user account management features. Referrer's can now change their user name and email address.�

Thanks to all who've given their feedback this week.