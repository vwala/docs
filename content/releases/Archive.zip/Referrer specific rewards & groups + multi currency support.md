---
title: "Referrer specific rewards & groups + multi currency support"
meta_title: "2017-08-17"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

Great news! You can now pay your referrers differently!�

We've added:

*   The ability to organised your referrers into different groups (referrers page)
*   The ability to reward each referrer group differently and create referrer specific promotions (promotions page)
*   The ability to hide promotion details from your referrer sign-up page (See My Account > Store Settings).
*   We've added currency support for our non-US customers.�
*   And finally, we've also added the ability to pay referrers manually using your bank account! This was a popular request and we are pleased to release it.�

Last but not least, behind the scenes we have:

*   Optimised the referrers form
*   Optimised our order tracking algorithm.�
*   Improved the way we geo-locate IP address and;
*   Improved our XSS compliance.�

Thanks to everyone who submitted feature requests. Keep them coming :)