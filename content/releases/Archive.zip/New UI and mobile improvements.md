---
title: "New UI and mobile improvements"
meta_title: "2017-06-13"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

For this release we've focused on making improvements to our user experience.  
  
What's new:

*   New product page and pricing tables.
*   We've greatly improved the usability of the product on mobile devices. This is important as 60% of referrers interact with apps using their phones.�

We're really happy with the new look and we hope you enjoy it too. If you have any feedback, let us know :)