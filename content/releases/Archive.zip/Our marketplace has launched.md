---
title: "Our marketplace has launched!"
meta_title: "2018-01-20"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

For this release we have:

*   Launched the first version of our marketplace - a place for brands and influencers to discover each-other and form marketing partnerships. �
*   The marketplace is only available for influencers at present but will soon be rolled out to merchants as well.�

Thanks all for the feedback. Keep it coming!