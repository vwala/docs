---
title: "Mail templates & referral link customization"
meta_title: "2018-08-30"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

Hi all,

In this release, we have:

*   You can now set which page your referrer's links will take your leads (i.e. potential customers) when they click on a referrer's link.
*   Added email template customization. This means you can brand/customize the emails that we send to your referrers on your behalf. The template system includes live variable substitution for smarter templates. This new feature is found in my account > store settings.
*   You can now invert the colour palette of your logo. This is useful when you have a logo that does not display well over a white background.