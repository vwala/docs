---
title: "Improved customisation and various optimisations"
meta_title: "2017-12-24"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

For this release, we've focused on making the behaviour of [vwa.la](http://vwa.la) more customisable. We have also made many improvements behind the scenes.�

*   You can now configure our anti-fraud system, by enabling / disabling self-orders (my account > store settings)
*   You can also now enable/disable email notifications for specific events (my account > store settings)
*   We've added filtering to the orders table to make it easier to filter by paid, unpaid orders. (top right of orders table)
*   We've also added a new tool to the orders table (bottom of the table) that will enable you to re-fresh the status of your orders with Shopify as well as re-fresh the status of any PayPal commission payments. �
*   We've made a number of improvements to how we manage billing.�

**What's next?**  
Behind the scenes we've been hard at work on creating our merchant / influencer marketplace which we plan to release in early January. We will also be releasing an enhanced referrer sign-up process that will obtain even richer information from new referrers about their social media marketing channels.�

Thanks all for the feedback. We will start incorporating your feedback asap :)