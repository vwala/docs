---
title: "PayPal & referrer management improvements"
meta_title: "2018-01-14"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

For this release we have:

*   Made various improvements to our PayPal integration which will make managing PayPal payments much simpler
*   Added the ability for merchants to bulk remove referrers�
*   Reduced the file size of our in-store widget code (even faster loading)

Thanks all for the feedback. We will start incorporating your feedback asap :)