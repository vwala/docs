---
title: "Referrer code changing and UX improvements"
meta_title: "2018-02-10"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

Hi all, in this release we have:

*   Added the ability for referrers to change their referrer code. This can be done from the homepage of their dashboard (i.e. discount code/link section).
*   We've updated our dashboard charts to now show you "sales" and "earnings". So you can easily see a summary of your income and expenses (commission paid/owed)
*   We've added the ability to filter orders by date. Thanks Tom for the feedback.�
*   We've also reduced the size of the [vwa.la](http://vwa.la) web application by 25%! We'll continue to make [vwa.la](http://vwa.la) as small and fast loading as possible.�

Keep the feedback coming!