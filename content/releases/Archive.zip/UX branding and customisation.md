---
title: "UX branding and customisation"
meta_title: "2017-07-20"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

This week we've focused on making the [vwa.la](http://vwa.la) UX branded and configurable.�

What's new
----------

**Sign-up widget improvements**  
The in-store sign-up widget can now be turned off or re-positioned. This can be done from your [vwa.la](http://vwa.la) dashboard (My accounts > store settings)

![](https://downloads.intercomcdn.com/i/o/29391893/49c29ef6fed43a4180067ea9/Screen+Shot+2017-07-23+at+18.30.43.png)

**Branded sign-up pages!**  
You can also brand your referrer sign-up form. You can configure this feature from your [vwa.la](http://vwa.la) dashboard (My accounts > store settings).�

![](https://downloads.intercomcdn.com/i/o/29391926/0c772c234c2d91a269c4005b/Screen+Shot+2017-07-23+at+23.21.43.png)

What's next?
------------

**Referrer specific promotions  
**Our next release will focus on improving [promotions](https://intercom.help/vwala/merchant-help/promotions) (sales campaigns for your referrers). Previously we introduced product/collection specific promotions to help focus your referrer's selling efforts. In this release we will be introducing referrer specific promotions, which is a powerful way of grouping referrers into different reward structures (i.e. VIP influencers).�

Thanks everyone for the great product feedback, if there is anything you'd like to see implemented let us know :)