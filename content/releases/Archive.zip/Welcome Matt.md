---
title: "We have a new team member!"
meta_title: "Welcome Matt"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

Since [vwa.la](http://vwa.la) launched a couple of weeks ago, we've had tremendous uptake from merchants like yourself. We're really pleased that people are liking what we are doing. As part of our commitment to you to keep improving our product and service, we've just recruited a new developer - Matt. Matt brings a wealth of technical experience to the team and is sure to be a large asset for us.

You can see his friendly face on our homepage!

Welcome Matt :)