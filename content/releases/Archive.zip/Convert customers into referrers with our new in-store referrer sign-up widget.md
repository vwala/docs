---
title: "Convert customers into referrers with our new in-store referrer sign-up widget"
meta_title: "2017-07-01"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

Hi all, we have some exciting news to share. We have just launched a new in-store widget that will help convert your customers into referrers!

What's great about this widget is that it:�

*   Is installed into your store front automatically
*   Is customizable and;
*   Most importantly, it takes care of 1) marketing your referral marketing program to your customers 2) educating them about it's benefits and 3) does the hard work of converting customers into referrers via your customised referrer sign-up form.

We're just getting started with this feature. Expect many more improvements in this area over the next few weeks. If you have any feedback, let us know :)