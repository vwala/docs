---
title: "Tracking and In-app payment improvements"
meta_title: "2018-07-01"
meta_description: ""
keywords:
    - concepts
    - ghost
    - publishing
    - features
sidebar: "concepts"
---

Hi all,

In this week's release, we have:

*   Improved our in-app payment feature. You can now pay sales commission out on all un-paid orders via PayPal in one step. No selection required! You can of course still pay commission on only a select number of orders at a time. We've also made quite a few usability improvements to the form.
*   We've fixed some issues where IP tracking wasn't working for clients in India.�
*   We've improved our handling of POS orders to be more robust.
*   We've improved our support of partially fulfilled orders.�
*   We've spent some time re-checking our security implementation and have tightened up a few areas even more. Making sure [vwa.la](http://vwa.la) protects your privacy is always a #1 priority.�
*   We've optimised our PayPal payment processing back-end to be much more efficient.�

Thanks to all who have given their feedback. We know that we haven't been publishing weekly release notes consistently. I'll make sure we do a better job of it :)